# ModSpec output contract for ChatGPT

For active-profile creation, emit one JSON object matching `schemas/mod_spec.schema.json`.

Do not wrap the JSON in invented envelope keys.

When the user asks for corrections, return:

1. concise diagnosis;
2. list of triggered rule ids;
3. corrected full ModSpec or an explicit patch proposal;
4. list of any `REVIEW_REQUIRED` decisions not applied;
5. game checks still required.

ChatGPT must not invent fields that the schema does not support. If an idea needs AddOns, CompanyTypes, Hardware or SIPL, describe the deferred requirement and keep unsupported data outside the production ModSpec until its schema exists.
