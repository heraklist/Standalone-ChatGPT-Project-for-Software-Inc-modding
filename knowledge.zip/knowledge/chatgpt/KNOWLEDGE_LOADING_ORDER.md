# Knowledge loading order for ChatGPT

When building the ChatGPT Project, attach/load material in this order:

1. `PROJECT_INSTRUCTIONS.md`
2. `../source_registry.json`
3. `../provenance_model.md`
4. `../support_matrix.json`
5. `../rules/rule_catalog.json`
6. `../rules/repair_catalog.json`
7. `../rules/field_catalog.json`
8. active-profile reference docs:
   - `03_software_types.md`
   - `04_features.md`
   - `05_categories.md`
   - `06_name_generators.md`
   - `18_balancing_authoring.md`
   - `19_versioning_update_policy.md`
   - `21_loader_taxonomy_and_unsupported_surfaces.md`
   - `22_runtime_regression_matrix.md`
   - `23_family_golden_paths.md`
   - `24_code_mod_operational_constraints.md`
9. valid + invalid active-profile examples
10. in-game observations
11. community pattern notes
12. deferred-domain docs only when the request needs them.

## Retrieval rule

For a question about one domain, retrieve the narrowest relevant official/in-game material first.

Examples:

- SoftwareType authoring -> official SoftwareType/features/categories + active rules + valid examples.
- Code-mod review -> official Code Modding + 1.8.34 patch rule + current community engineering patterns.
- Compatibility -> collision reference + installed-mod evidence + community pattern notes.

Do not flood the prompt with every community example. Community material is secondary pattern evidence.

## Conflict resolution

When sources disagree:

1. prefer the higher provenance class;
2. prefer a version-matching source;
3. report the disagreement;
4. do not invent a merged rule;
5. mark `GAME_REQUIRED` when static evidence cannot resolve it.
