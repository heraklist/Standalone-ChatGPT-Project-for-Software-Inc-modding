# ChatGPT authoring checklist

Before returning a ModSpec:

- [ ] `schemaVersion = 0.2.0`
- [ ] target game/profile/version are explicit
- [ ] mod id is stable snake_case
- [ ] each SoftwareType id/name is unique
- [ ] exactly 3 submarket names
- [ ] at least one explicit category
- [ ] category names unique
- [ ] category vectors are length 3 and align with submarket order
- [ ] at least one forced root feature with no unlock
- [ ] no duplicate root specialization
- [ ] root/category references resolve
- [ ] only level 1/2 child features
- [ ] no shadowed child category filter
- [ ] DevTime/CodeArt/server values fit current validator bounds
- [ ] NameGenerator behavior is explicit (custom external reference or ModForge fallback)
- [ ] no deferred domain is smuggled into the active schema
- [ ] balance assumptions are labeled as assumptions
- [ ] in-game commands are listed as required evidence, not claimed PASS
