# Software Inc Modding Research Report — 2026-08-25

## Version status

- Latest public patch observed: **Beta 1.8.42**, released 2026-08-20.
- Last ModForge in-game semantic tests: **Beta 1.8.41**.
- The 1.8.42 patch notes list a web-upload fix and do not list a mod-format change; this is not a substitute for a ModForge 1.8.42 smoke test.
- The official Data Modding wiki's downloadable vanilla-data archive currently stops at **Beta 1.7.15**.

## Official documentation covered

- TyD
- mod taxonomy/install roots
- Data Modding
- SoftwareTypes
- Categories
- SpecFeatures/SubFeatures
- level-3 SIPL
- NameGenerators
- CompanyTypes
- Personalities
- AddOns
- Hardware/manufacturing
- debugging/console validation
- C# / DLL code mods
- furniture/material/localization overview

## Recent data-mod corpus

### Software Galore
Open-source Beta 1.8-era large data expansion. Useful for:
- modern folder layout;
- large SoftwareType trees;
- NameGenerator usage;
- localization packaging;
- balance-pattern regression cases.

### ModernInc
Updated August 2026. Useful for:
- large merged catalogs;
- compatibility bridges;
- validation + rollback;
- respecting foreign mod ownership.

### Game Evolution / Office Software
Updated August 2026. Their changelogs explicitly document a serious cross-mod compatibility issue/fix. Game Evolution also demonstrates current level-3 scripted-feature usage.

## Recent code-mod corpus

### Company Intelligence
Open-source and explicitly validated on Beta Steam 1.8.41. Useful for:
- C# 3/.NET 4 source-mod workflow;
- Workshop-compatible source packaging;
- local verification builds;
- pure-rule tests vs game runtime tests;
- lifecycle cleanup;
- version/runtime regression matrices.

### Mod Framework / LimitlessTeams
Useful for:
- DLL permission/audit concepts;
- Harmony/library dependency identity;
- real type-collision failures;
- runtime patch verification.

## Important 1.8 code-mod change

Beta 1.8.34 introduced a code-mod security change:
- mods using `UnityEngine.PlayerPrefs` no longer load;
- migrate to `ModBehaviour.SaveSetting`/`LoadSetting`;
- Serialize/Deserialize support and debugging tooling were expanded.

This is stored as a version-specific hard lint rule.

## Knowledge-policy result

Hard rules come only from:
- in-game observed behavior;
- official documentation;
- versioned vanilla evidence.

Community examples supply patterns and regression scenarios, not parser truth.

## Known evidence gap

We do not yet have a current **1.8.42 vanilla-data snapshot**.

The next high-value evidence feature is a read-only local vanilla importer that hashes and parses the user's installed game data, so the validator can resolve dependencies and compare overrides against the exact installed version.
