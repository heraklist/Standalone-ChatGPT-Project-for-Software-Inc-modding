# Software Inc ModForge Knowledge Pack

Version: **0.1.1**  
Research date: **2026-08-25**  
Latest public patch observed: **Software Inc Beta 1.8.42**  
Last ModForge in-game validation evidence: **Beta 1.8.41**

This directory is the shared knowledge layer for:

1. the desktop validator/compiler;
2. future deterministic repair/suggestion logic;
3. the ChatGPT Project authoring layer;
4. regression/evaluation tests.

## Why this exists

A working community mod is not automatically a specification. The official wiki can describe engine semantics while its downloadable vanilla archive may lag the current game. In-game errors can reveal constraints that are not obvious from a field table.

ModForge therefore separates:

```text
sources
  ↓
provenance + confidence
  ↓
machine-readable rules
  ↓
validator issue-code mapping
  ↓
repair policy
  ↓
examples + evals
  ↓
ChatGPT authoring contract
```

## Directory map

```text
knowledge/
├── README.md
├── source_registry.json
├── provenance_model.md
├── support_matrix.json
├── reference/
│   ├── 00_mod_taxonomy.md
│   ├── 01_tyd.md
│   ├── ...
│   └── 17_vanilla_data_gap.md
├── rules/
│   ├── rule_schema.json
│   ├── rule_catalog.json
│   ├── repair_catalog.json
│   ├── field_catalog.json
│   └── validator_code_map.json
├── examples/
│   ├── valid/
│   ├── invalid/
│   └── code_mod_skeleton/
├── observations/
│   └── in_game_findings.json
├── community/
│   ├── examples_registry.json
│   ├── data_mod_patterns.md
│   └── code_mod_patterns.md
├── chatgpt/
│   ├── PROJECT_INSTRUCTIONS.md
│   ├── AUTHORING_CHECKLIST.md
│   ├── MODSPEC_OUTPUT_CONTRACT.md
│   └── REPAIR_RESPONSE_SCHEMA.json
└── evals/
    ├── validation_cases.json
    ├── repair_cases.json
    └── authoring_cases.json
```

## Source policy

Hard compatibility errors require strong evidence. Source precedence is documented in `provenance_model.md`.

Community mods are useful for:

- file/package structure;
- current ecosystem patterns;
- real compatibility failures;
- regression scenarios;
- code organization.

They are **not** automatically used to invent parser rules.

## Current production scope

The active `beta-1.x-data` profile covers:

- `meta.tyd`;
- SoftwareTypes;
- explicit Categories;
- root SpecFeatures;
- level 1/2 SubFeatures;
- deterministic NameGenerator fallback;
- deterministic preview/folder/ZIP export.

CompanyTypes, Personalities, AddOns, Hardware, SIPL, code mods, furniture, materials and localization are documented here so the architecture can grow without relearning the domain, but production writers remain deferred unless `support_matrix.json` says otherwise.

## Repair policy

Repairs are classified:

- `SAFE_AUTO`
- `REVIEW_REQUIRED`
- `NEVER_AUTO`

The app should never turn a balance or semantic design choice into an invisible auto-fix.

## Validation

Run:

```text
npm run knowledge:check
```

This validates rule/source references, repair references, validator-code coverage, eval file integrity, ChatGPT contract tokens and the research code-mod skeleton.

## Important vanilla-data caveat

The official Data Modding page currently exposes downloadable vanilla data archives only through Beta 1.7.15, while the latest public patch observed version is 1.8.42 and ModForge's last in-game evidence is 1.8.41.

Do not label the 1.7.15 archive as exact 1.8.41 vanilla data. A future local-game importer should snapshot and hash the user's current installed vanilla content as versioned evidence.


## feedback16 research/evidence additions

The knowledge pack now also contains:

- explicit five-family loader taxonomy;
- unsupported-surface guidance for scenario/map and external save-editor requests;
- console/debug command catalog;
- family-specific golden paths;
- runtime regression matrix;
- code-mod Workshop/full-access/network/UI constraints;
- machine-readable game validation receipt schema and local 1.8.42 test plan.

`1.8.42` is labeled **latest public patch observed**. It becomes ModForge `TESTED` only after a matching in-game receipt passes.
