# Knowledge provenance and confidence

Every ModForge rule must say **why it exists**. Validation must never learn a hard compatibility rule from a random working mod.

## Precedence

1. **IN_GAME_OBSERVED** — reproduced behavior/error from the declared game version.
2. **OFFICIAL** — current Software Inc official documentation.
3. **VANILLA** — shipped game data for a named version.
4. **COMMUNITY_VERIFIED** — working recent mod used as pattern evidence.
5. **PROFILE_RESTRICTION** — deliberate ModForge scope restriction.
6. **MODFORGE_POLICY** — deterministic/safety behavior added by ModForge.
7. **HEURISTIC** — balance or quality advice only.

A lower-precedence source cannot silently override a higher-precedence rule.

## Confidence

- `1.00`: reproduced in-game or explicit official constraint.
- `0.90–0.99`: official semantics with small implementation interpretation.
- `0.70–0.89`: multiple compatible examples or community patterns.
- `<0.70`: heuristic/suggestion only.

## Enforcement

- `ERROR`: block export for the active profile.
- `WARNING`: export may continue, but compatibility/behavior risk exists.
- `SUGGESTION`: quality or balance improvement.
- `INFO`: contextual explanation.

## Validation class

- `STATIC_PROVABLE`: ModForge can prove the rule before export.
- `GAME_REQUIRED`: only the game can conclusively validate it.
- `BALANCE_HEURISTIC`: requires gameplay/balance judgment.

## Repair class

- `SAFE_AUTO`: deterministic, reversible, and does not change author intent.
- `REVIEW_REQUIRED`: may alter gameplay intent; show patch + rationale and require approval.
- `NEVER_AUTO`: scripting/code, destructive overrides/deletes, or ambiguous semantic changes.

No `GAME_REQUIRED` rule may be marked PASS solely from static validation.


## Engine truth versus ModForge enforcement

`ERROR` severity does **not** automatically mean "Software Inc engine rule".

There are two different reasons an export can be blocked:

### Engine-truth compatibility rule

Use only evidence classes capable of establishing game semantics:

- `IN_GAME_OBSERVED`
- `OFFICIAL`
- version-matched `VANILLA`

These may be described as Software Inc compatibility/parser/runtime rules within their stated version scope.

### ModForge enforcement rule

`PROFILE_RESTRICTION` and `MODFORGE_POLICY` may also block export, but the diagnostic must say that the restriction belongs to ModForge/current profile.

Examples:

- requiring at least one explicit category in the first-Beta profile even if the engine can synthesize a default category;
- safe snake_case ids for deterministic paths;
- refusing destructive/foreign-mod writes.

`COMMUNITY_VERIFIED` and `HEURISTIC` evidence must never be silently promoted into universal engine truth.

A diagnostic UI should display `provenance` next to severity so an author can distinguish "the game requires this" from "ModForge intentionally requires this".
