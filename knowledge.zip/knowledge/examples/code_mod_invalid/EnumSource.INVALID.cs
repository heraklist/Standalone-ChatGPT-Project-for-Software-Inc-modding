public enum InvalidWorkshopMode
{
    Off,
    On
}

public class InvalidEnumBehaviour : ModBehaviour
{
}
