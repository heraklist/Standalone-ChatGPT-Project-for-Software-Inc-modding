public class PrivilegedMeta : ModMeta
{
    public static bool GiveMeFreedom = true;

    public override string Name
    {
        get { return "Privileged Knowledge Example"; }
    }
}
