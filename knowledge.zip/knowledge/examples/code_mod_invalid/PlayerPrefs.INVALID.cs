using UnityEngine;

public class InvalidSettingsBehaviour : ModBehaviour
{
    public override void OnActivate()
    {
        PlayerPrefs.SetInt("Enabled", 1);
    }
}
