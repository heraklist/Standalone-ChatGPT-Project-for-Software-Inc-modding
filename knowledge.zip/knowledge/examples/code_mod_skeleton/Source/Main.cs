using UnityEngine;

namespace ModForgeKnowledgeExample
{
    internal sealed class Main : ModMeta
    {
        public override string Name
        {
            get { return "ModForge Knowledge Example"; }
        }

        public override void Initialize(ModController.DLLMod parentMod)
        {
            base.Initialize(parentMod);
        }
    }
}
