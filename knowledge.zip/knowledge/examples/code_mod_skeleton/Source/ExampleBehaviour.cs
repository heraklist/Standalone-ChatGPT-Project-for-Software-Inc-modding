using UnityEngine;

namespace ModForgeKnowledgeExample
{
    internal sealed class ExampleBehaviour : ModBehaviour
    {
        private bool _active;

        public override void OnActivate()
        {
            if (_active)
            {
                return;
            }

            _active = true;
            Debug.Log("ModForge knowledge example activated.");
        }

        public override void OnDeactivate()
        {
            _active = false;
        }

        private void OnDestroy()
        {
            _active = false;
        }
    }
}
