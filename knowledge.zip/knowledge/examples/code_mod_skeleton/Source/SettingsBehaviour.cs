using UnityEngine;

namespace ModForgeKnowledgeExample
{
    public class SettingsBehaviour : ModBehaviour
    {
        private bool _notifications;

        public override void OnActivate()
        {
            _notifications = LoadSetting<bool>("Notifications", true);
        }

        public override void OnDeactivate()
        {
            SaveSetting("Notifications", _notifications);
        }
    }
}
