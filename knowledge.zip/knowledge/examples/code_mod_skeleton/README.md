# Research code-mod skeleton

This is a **knowledge example**, not a ModForge-generated production mod.

Target assumptions:

- Software Inc Beta 1.8 family
- game-compiled Workshop source
- C# 3 syntax
- .NET Framework 4
- no enums
- no external dependencies
- no privileged file/network access

Before use, compile against the local Software Inc assemblies and run the game's source-compiler/runtime regression checks.

Recommended package layout:

```text
DLLMods/ExampleKnowledgeMod/
├── Source/
│   ├── Main.cs
│   └── ExampleBehaviour.cs
├── meta.tyd
└── TypeInfo.txt
```

Do not commit or redistribute proprietary Software Inc/Unity assemblies.
