# AddOn / Hardware research example notes

This file is intentionally not a production TyD fixture. AddOn and Hardware writers are deferred.

Use the official Data Modding reference before turning this into executable game data.

An AddOn definition belongs inside a SoftwareType `AddOns` list and can include name, unlock, category applicability, development/balance fields, feature requirements, manufacturing and a NameGenerator.

A Hardware SoftwareType adds `Hardware True` and a `Manufacturing` table containing Components, Processes and FinalTime. Exactly one assembly process should produce the final output.
