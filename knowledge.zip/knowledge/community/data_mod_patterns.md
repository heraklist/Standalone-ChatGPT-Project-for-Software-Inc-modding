# Recent data-mod pattern notes

These notes summarize patterns, not engine guarantees.

## Large catalogs

Modern 1.8-era content packs commonly define many SoftwareTypes and deep feature trees. ModForge therefore needs more than per-file syntax validation:

- merged-catalog uniqueness;
- reference resolution;
- specialization coverage;
- category/submarket consistency;
- NameGenerator resolution;
- compatibility/load-order analysis;
- balance test planning.

## Compatibility is a first-class feature

Recent Game Evolution / Office Software changelogs explicitly mention a serious compatibility fix. ModernInc describes compatibility bridges and rollback if merged-catalog validation still fails.

Future scanner design:

```text
installed mods
   ↓
parse into normalized catalog
   ↓
apply declared load/override semantics
   ↓
detect collisions + dangling references
   ↓
simulate proposed repair in memory
   ↓
revalidate entire merged catalog
   ↓
show proposal
```

Never rewrite foreign mod files in place.

## Community syntax is not authority

A working community file can contain legacy/deprecated forms or version-specific quirks. Extract the pattern, attach the source, and only promote it to a hard rule when official/vanilla/in-game evidence supports it.
