# Recent code-mod pattern notes

## Source mods

Current open-source 1.8.41 evidence supports a disciplined source-mod layout:

```text
mod/
├── Source/
├── Tests/
├── Localization/
├── meta.tyd
├── TypeInfo.txt
├── build verification scripts
└── project files used only for development
```

Useful lint targets:

- C# 3 compatibility;
- no enums for game-compiled straight `.cs`;
- no accidental modern language features;
- ModMeta identity stability;
- lifecycle cleanup;
- event subscription/unsubscription pairing;
- no game/Unity DLLs committed;
- no privileged access without explicit declaration;
- Workshop package excludes development artifacts;
- source transformed by the game's own injection logic still compiles.

## DLL mods and frameworks

Current DLL mods can depend on runtime libraries and patch frameworks. This creates extra scanner dimensions:

- dependency filename/version;
- strong-name/type identity;
- duplicate Harmony loaders;
- permission requirements;
- patched method overlap;
- install location;
- external file/network privileges;
- runtime unload/reload behavior.

These checks belong in a future code-mod security/compatibility linter, not the current data-mod writer.
