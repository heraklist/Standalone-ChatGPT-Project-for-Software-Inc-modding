# Family golden paths

These are operational workflows, not a claim that every optional field/content type is supported by the current ModSpec writer.

## Data mod

```text
Mods/<Mod>/
  SoftwareTypes/
  CompanyTypes/
  NameGenerators/
  Personalities.tyd
        ↓
TyD/static validation
        ↓
RELOAD_MOD
        ↓
CHECK_SPEC_REP / TEST_DEV_MOD / CHECK_ADDON_MARKET as applicable
        ↓
AI simulation when applicable
        ↓
cross-mod conflict smoke
        ↓
Workshop-style package
```

The current ModForge production subset is narrower: SoftwareTypes, Categories, level 0–2 features and NameGenerator fallback.

## Workshop-compatible C# code mod

```text
.NET Framework 4 development project
        ↓
C# source kept within C# 3-compatible subset
        ↓
ModMeta + ModBehaviour
        ↓
local validation against installed game assemblies
        ↓
DLLMods/<Mod>/Source + assets/localization
        ↓
RECOMPILE / RELOAD / console inspection
        ↓
new-save + existing-save runtime regression
        ↓
Workshop package containing source, not unrestricted DLL
```

Do not use enums in direct game-compiled source because the official documentation warns of a compiler/crash issue.

From Beta 1.8.34 onward, do not use `UnityEngine.PlayerPrefs`; use the documented ModBehaviour settings/save APIs.

## Furniture

```text
Model → OBJ
   ↓
Furniture TyD
   ↓
AutoBounds during prototype
   ↓
FURNITURE_DEBUG
   ↓
fix nav/snap/interactions
   ↓
EXPORT_FURNITURE_BOUNDS
   ↓
LOD + placement regression
   ↓
package
```

## Materials

```text
256×256 Base/Bump/Extra PNG assets
   ↓
materials.tyd
   ↓
unique serialization identity
   ↓
RELOAD_MATERIALS for already-loaded material sets
or full restart for first discovery
   ↓
color/weather/floor-sound visual regression
```

## Localization

Use comparison/reload tooling after game updates and generate mod-localization entries from the game when applicable.

Sources: official modding/console/furniture/material/localization documentation.
