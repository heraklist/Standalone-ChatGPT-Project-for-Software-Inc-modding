# SpecFeatures and SubFeatures

## Root SpecFeature (level 0)

A root feature maps to a specialization through `Spec`. Officially documented fields include:

- `Name`
- `Spec`
- `Description`
- `Dependencies`
- `Unlock`
- `DevTime`
- `Submarkets`
- `CodeArt`
- `Server`
- `Optional`
- `SoftwareCategories`
- nested `Features`

A SoftwareType should not define two root SpecFeatures for the same specialization.

`Optional True` makes a root feature optional. Omitting it means the feature is forced. Current ModForge additionally enforces the 1.8.41 observed rule that at least one forced root feature has no `Unlock`.

## SubFeature

SubFeatures include `Name`, `Description`, `Level`, `Unlock`, `DevTime`, `Submarkets`, `CodeArt`, `Server`, `SoftwareCategories` and, for scripted level 3 features, script entry points.

Current ModForge supports levels 1 and 2 only.

## Level 3

Official documentation describes level 3 as SIPL-scripted. Level 3 does not satisfy submarkets and is not selected by AI, so it behaves more like an optional player bonus. Do not silently downgrade a level 3 feature to level 1/2.

## Category filters

A parent root feature's `SoftwareCategories` restriction overrides child restrictions. ModForge should flag child restrictions beneath a restricted parent because author intent would otherwise be silently ignored.

Source: `official-data-modding`.
