# SIPL and level-3 feature scripts

SIPL is Software Inc's interpreted scripting language. It resembles C# but intentionally has a much smaller language surface.

Important differences from C# include:

- no namespaces/classes/functions defined by the script;
- `var` only, without typed variable declarations;
- number operations are effectively double-oriented;
- no `for` loop; use `foreach`;
- no compound assignment/increment operators;
- no `new` keyword in the usual C# form;
- no multiline comments;
- enum usage differs from C# qualification rules.

Official data-mod documentation uses SIPL for level-3 feature scripts and exposes script entry points such as end-of-day/after-sales contexts.

Performance matters because SIPL is interpreted and reflection-heavy. The official guide also says AI will not choose level-3 features.

Current ModForge policy:

- knowledge is available;
- generation remains deferred;
- automatic repair must never manufacture or rewrite SIPL;
- future script linting should parse syntax and inspect allowed scope members, but game runtime tests remain mandatory.

Sources: `official-sipl`, `official-data-modding`.
