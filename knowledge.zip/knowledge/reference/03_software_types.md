# SoftwareType reference

SoftwareType is the root definition for a product class.

Officially documented root concepts include:

- `Name`, `Description`, `Unlock`;
- `Random`, `IdealPrice`, `OptimalDevTime`;
- `Categories`;
- `Popularity`, `Retention`, `Iterative` for the implicit/default-category case;
- `OSSupport`, `OneClient`, `InHouse`;
- `NameGenerator`;
- `SubmarketNames`;
- `Features`;
- AddOn and Hardware structures covered separately.

## Categories

The older singular `Category` field is deprecated in Beta 1-era documentation. Prefer `Categories`.

Software Inc can create a default category if `Categories` is absent, but the current ModForge `beta-1.x-data` profile deliberately requires at least one explicit category. That is a **profile restriction**, not a universal engine requirement.

## Submarkets

`SubmarketNames` defines exactly three ordered market dimensions. Category and feature vectors use the same order. ModForge should treat a mismatch in ordering/length as a hard structural error.

## OSSupport

Official data documentation permits OS support to be represented as:

- `True`;
- one OS category;
- a list of OS categories.

When software is not OS-dependent, omit the field rather than emitting a false-like placeholder in the current ModForge profile.

## 1.8.41 observations

Two semantic rules were reproduced in the game:

1. at least one root feature must be forced and have no unlock date;
2. every category must resolve a NameGenerator, either on the category or through the SoftwareType root fallback.

Sources: `official-data-modding`, `observed-1.8.41-forced-feature`, `observed-1.8.41-name-generator`.
