# Balancing and authoring guidance

Compatibility validation and gameplay balance are different problems.

A TyD file can parse correctly and still create a SoftwareType whose market cannot be satisfied, whose development time is unreasonable, or whose specializations make education useless.

## Official balance primitives

### OptimalDevTime

`OptimalDevTime` is expressed in one-employee months. The official data-mod guide also states that it influences how many features are needed to satisfy submarkets.

A validator can check that the value is finite/positive. It cannot prove that the chosen feature tree actually produces good gameplay.

### Submarket ratios

SoftwareType `SubmarketNames` defines three ordered dimensions.

Category and feature `Submarkets` vectors are ratios. The numbers are normalized by the game, so `[3; 4; 5]` represents the same proportions as `[0.25; 0.333...; 0.416...]`.

ModForge should therefore:

- preserve author proportions;
- detect invalid length / negative / all-zero vectors statically;
- optionally display normalized percentages;
- never "rebalance" the ratios silently.

### DevTime and coverage

Level 0–2 features contribute to submarket satisfaction. Level 3 features do not.

Static heuristics can estimate total development cost and whether every market dimension receives some coverage, but only the game can confirm the actual market result.

## Required game checks

### `TEST_DEV_MOD X Y Z`

Run for every supported category. The official guide says it reports balancing information and whether 100% interest can be reached with some targeting.

Result class: `GAME_REQUIRED`.

### `CHECK_SPEC_REP X`

Run for the mod to ensure specialization levels are represented so education levels do not become useless.

Result class: `GAME_REQUIRED`.

### `CHECK_ADDON_MARKET X Y Z`

Required when AddOns are supported. It checks whether all intended add-on markets can be fulfilled.

Result class: `GAME_REQUIRED`.

## ChatGPT authoring heuristics

These are suggestions, not engine laws:

- prefer abstract long-lived capabilities over duplicate era-specific replacements;
- use unlock years and tech levels for progression;
- make the forced baseline small enough that the product has a coherent minimum form;
- use optional roots for genuinely optional specializations;
- avoid making every category demand every specialization;
- aim for each submarket to have more than one meaningful feature route;
- keep CodeArt consistent with the semantic feature (for example network protocols are mostly code, visual asset creation is more art-heavy);
- avoid huge jumps in total DevTime unless the concept is deliberately enterprise/hardware-scale.

## Future deterministic metrics

The app can safely compute and display:

- normalized category/feature submarket percentages;
- total root + child DevTime by specialization;
- CodeArt weighted development split;
- earliest/latest unlock per branch;
- coverage matrix: category × submarket × feature;
- specialization count / duplicate checks;
- forced baseline size;
- external dependency graph;
- unresolved merged-catalog references.

These metrics should feed suggestions, not auto-apply balance changes.

Sources: `official-data-modding`, `official-console`.
