# Runtime regression matrix

Static validation and compilation do not replace game runtime testing.

## Minimum release regression matrix

For every release candidate, record the result of:

1. clean local installation;
2. game start with the candidate installed;
3. new-save scenario;
4. existing-save scenario when relevant;
5. enable → disable → re-enable when the mod family supports it;
6. game restart with the mod still installed;
7. final Workshop-style package/install layout;
8. output/error log inspection;
9. exact game version;
10. hashes of the source candidate and installed mod artifact.

For mods that persist save data, also test:

- loading an old save after a mod update;
- disable/remove behavior when supported;
- migration/default behavior for missing/new fields.

## Data-mod runtime gates

Current first-Beta SoftwareType work should capture:

- mod discovery and metadata load;
- `RELOAD_MOD`;
- `CHECK_SPEC_REP`;
- `TEST_DEV_MOD` for each supported SoftwareType/category;
- `CHECK_ADDON_MARKET` when AddOns are supported;
- AI simulation when CompanyTypes are involved;
- cross-mod conflict smoke when overlapping catalog mods are installed.

## Code-mod runtime gates

Keep compilation and runtime matrices separate.

Code mods additionally need:

- recompile/reload/unload behavior;
- lifecycle cleanup after disable/re-enable and scene transitions;
- existing-save behavior;
- localization;
- UI resolution/layout cases when UI is modified;
- absence of new exceptions in logs;
- networking compatibility when network messages are used.

## Evidence boundary

A result is `GAME_PASS` only when the matching game test was actually executed and attached to a validation receipt.

Source: `official-console`, `official-data-modding`, `official-code-modding`; current community engineering pattern evidence: `community-company-intelligence`.
