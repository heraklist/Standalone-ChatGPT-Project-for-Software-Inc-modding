# Software categories

A category changes market/balance behavior inside one SoftwareType.

Documented fields include:

- `Name`, `Description`, `Unlock`;
- `Popularity`;
- `Submarkets`;
- `TimeScale`;
- `Retention`;
- `IdealPrice`;
- `Iterative`;
- `NameGenerator`.

## Validation

For the current profile:

- category names are unique within a SoftwareType;
- `Submarkets` contains exactly three values;
- the values follow the SoftwareType `SubmarketNames` order;
- the ratio cannot be structurally unusable (for example all-zero);
- `TimeScale` stays within its documented 0..1 range;
- every category must resolve a NameGenerator;
- `SoftwareCategories` references from features must point to a declared category.

Balance values should be treated separately from parser/compatibility rules. A plausible but poor balance is a suggestion/warning, not automatically a parser error.

Sources: `official-data-modding`, `observed-1.8.41-name-generator`.
