# Data mod structure

A local data mod lives under:

```text
Software Inc/
└── Mods/
    └── <mod-folder>/
        ├── meta.tyd
        ├── Personalities.tyd
        ├── SoftwareTypes/
        ├── CompanyTypes/
        ├── NameGenerators/
        └── ...
```

The official data-mod loader recognizes TyD content under the mod folder and specific content subdirectories.

Current ModForge first-Beta output is intentionally narrower:

```text
<mod-id>/
├── meta.tyd
├── SoftwareTypes/
│   └── <software-id>.tyd
└── NameGenerators/
    └── <generated-id>.txt   # when required
```

CompanyTypes, Personalities, AddOns, Hardware and SIPL are documented in the knowledge pack but are not yet production writers in ModSpec 0.2.

Source: `official-data-modding`.
