# Current code-mod patterns — 1.8.41 ecosystem

Recent open-source **Company Intelligence 0.2** is particularly useful because its repository states runtime validation on Beta Steam 1.8.41 and intentionally targets C# 3 / .NET Framework 4.

Useful engineering patterns from that project:

- separate `Source/`, `Tests/`, localization, meta and TypeInfo;
- Workshop-compatible source distribution, with local DLL builds used for verification;
- build validation that applies the game's own source transformation before compiling;
- top-level helper types and C# 3-compatible syntax;
- no enums in Workshop source;
- explicit runtime regression matrix;
- idempotent cleanup of UI/event subscriptions;
- no proprietary game DLLs committed to the repository;
- pure business-rule tests separated from game-dependent runtime tests;
- output-log review after runtime scenarios.

These are **community-verified engineering patterns**, not official API requirements. They may inform linting and project templates but cannot override official documentation.

The 2026 DLL ecosystem also shows framework/dependency concerns. Mod Framework exposes permissions/auditing around privileged operations, while LimitlessTeams documents a real Harmony type-identity collision scenario when two incompatible Harmony-loading approaches coexist.

Sources: `community-company-intelligence`, `community-mod-framework`, `community-limitless-teams`.
