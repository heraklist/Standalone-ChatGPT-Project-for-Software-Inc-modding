# CompanyTypes

CompanyTypes define simulated AI company behavior.

The official data-mod guide warns that when a mod introduces new software types without corresponding company types, AI companies will not release that new software. This is not necessarily a parser failure for a player-only mod, so ModForge should surface it as a context-sensitive warning.

Documented CompanyType concepts include:

- `Specialization`
- `PerYear`
- `Min`
- `Max`
- `Frameworks`
- `Types`
- `Addons`
- `NameGen`

A `Types` entry can reference a `Software` type, an optional category, probability/chance behavior and force behavior.

`CompanyTypes/delete.txt` can remove built-in company types. Because delete/override operations change global simulation content, they are `NEVER_AUTO` in the repair policy.

## Future ModForge checks

- referenced SoftwareType exists after merged-catalog resolution;
- referenced category exists;
- CompanyType names/replacements do not collide unintentionally;
- AI participation warning for new software with no producer archetype;
- delete/override actions require explicit approval.

Source: `official-data-modding`.
