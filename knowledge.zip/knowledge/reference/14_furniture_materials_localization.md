# Furniture, materials and localization

## Furniture

Furniture packages live in `Furniture/<mod>/` and use TyD plus mesh/texture assets. The official tooling includes reload, debug overlay, thumbnail generation and boundary/point export commands.

## Materials

Material packages live under `Materials/<mod>/`. The official guide uses `materials.tyd` plus 256x256 PNG textures. Material textures are packed into game atlases, so size/count constraints are partly GPU/atlas constraints rather than ordinary data-mod semantics.

## Localization

Translations live under the Localization system. The game also supports name-list text files for employee names. Data-mod localization can be generated with `GENERATE_LOCALIZATION`.

Current ModForge status: documented but not yet schema/writer-supported.

Sources: `official-furniture`, `official-materials`, `official-modding`, `official-console`.
