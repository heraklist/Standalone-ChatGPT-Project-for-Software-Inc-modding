# AddOns

AddOns are defined inside a SoftwareType.

Documented concepts include:

- `Name`, `Description`, `Unlock`;
- `Categories`;
- `OptimalDevTime`, `Retention`;
- `Forced`, `PerUser`;
- `IdealPrice`;
- `BaseFeature`;
- `Features`;
- `Manufacturing`;
- `NameGenerator`.

The official console provides `CHECK_ADDON_MARKET` to verify that an add-on can cover its intended market. Because this is a game-level market computation, ModForge must classify that result as `GAME_REQUIRED`.

Current status: researched/deferred. Do not invent AddOn market balance automatically.

Sources: `official-data-modding`, `official-console`.
