# Hardware and manufacturing

A SoftwareType can become physical hardware by enabling `Hardware`. The official guide recommends defining a manufacturing process when hardware is enabled.

Manufacturing contains:

- `Components`;
- `Processes`;
- `FinalTime`.

Important structural constraints described by the guide include unique use of process inputs/outputs and exactly one process producing the final output.

Hardware design references can point to one or more visual designs and can vary by unlock year. Feature bindings can connect software features to particular hardware-design mesh objects.

The visual Hardware Design editor has its own mesh/attachment/texture rules and should remain a separate schema.

Current ModForge status: knowledge-ready, generation deferred. Manufacturing graphs are `REVIEW_REQUIRED`/`NEVER_AUTO`, never inferred silently.

Sources: `official-data-modding`, `official-hardware-design`.
