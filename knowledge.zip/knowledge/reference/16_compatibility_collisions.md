# Cross-mod compatibility and collision model

Recent 2026 data mods make cross-mod compatibility a first-class concern.

Game Evolution and Office Software both published a serious compatibility fix in August 2026. ModernInc describes catalog validation/bridging, rollback if a combined catalog remains invalid, and a policy of not editing foreign mod files.

## Data-mod collision classes

Future ModForge conflict scanning should detect:

- duplicate SoftwareType names without deliberate override intent;
- deprecated singular `Category` mixed with modern `Categories`;
- category name collisions inside merged/overridden SoftwareTypes;
- duplicate specialization root features after merges;
- missing feature dependencies;
- CompanyType references to missing software/categories;
- AddOn dependencies/market references that disappear after merge;
- NameGenerator id collisions, especially `[REPLACE]`;
- incompatible Override/Delete operations;
- different mods modifying the same vanilla SoftwareType;
- load-order-sensitive assumptions.

## Code-mod collision classes

The current DLL ecosystem adds:

- duplicate/competing Harmony runtimes;
- framework/library version conflicts;
- identical network ids;
- patching the same game method with incompatible assumptions;
- duplicate UI hooks/buttons;
- event handlers not removed on disable/reload;
- save-data identity clashes;
- privileged file/network behavior.

## Policy

Conflict repair is usually `REVIEW_REQUIRED`. ModForge should never edit another installed mod's files automatically. It can create a compatibility proposal or a new bridge mod, with explicit user approval.

Sources: `community-game-evolution`, `community-office-software`, `community-moderninc`, `community-limitless-teams`.
