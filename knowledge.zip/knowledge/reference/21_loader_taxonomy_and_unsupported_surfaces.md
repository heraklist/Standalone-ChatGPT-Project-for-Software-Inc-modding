# Loader taxonomy and unsupported surfaces

## Official loader families

Treat these as the primary Software Inc mod-loader families:

| Family | Local root | Primary format |
|---|---|---|
| Data | `Mods/<mod>/` | TyD, optional SIPL |
| Furniture | `Furniture/<pack>/` | TyD, OBJ, textures |
| Materials | `Materials/<pack>/` | `materials.tyd`, PNG |
| Code | `DLLMods/<mod>/` | C# source or DLL |
| Localization | `Localization/<language>/` | TyD, optional name-list text |

Hardware Design and Building Blueprints are supported content/editor/share systems, but they are not additional root-loader families in the same sense.

## Capability names are not loader types

- A UI extension is normally a Code mod.
- A gameplay overhaul can be Data/SIPL or Code.
- A graphics/content change can map to Materials, Furniture or Hardware Design depending on the asset.
- Hardware gameplay/manufacturing definitions are Data-mod content; Hardware Design is the visual product-design subsystem.

## Surfaces that must not be invented

### Scenario / campaign / map mod

The current official taxonomy does not document a standalone public scenario/map file-loader equivalent to the five roots above.

ModForge must therefore report this as **not documented as a current public loader type**, not silently invent a folder/schema.

### External savegame editor

The official code-mod API documents mod-side save/settings serialization, not a public external save-file schema for a standalone editor.

For save-editor-like functionality, prefer a Code mod using supported runtime APIs. Do not claim an external save schema is supported unless exact-version evidence exists.

## ChatGPT rule

When a user asks for a colloquial mod type such as "UI mod", "graphics mod", "map mod" or "save editor":

1. classify the request into the actual loader/content family;
2. state whether the family is production-supported by the current ModForge profile;
3. do not invent an unsupported root, schema or format.

Sources: `official-modding`, `official-data-modding`, `official-code-modding`.
