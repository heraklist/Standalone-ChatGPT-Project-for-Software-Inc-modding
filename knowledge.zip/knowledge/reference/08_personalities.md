# Personalities

Data mods can add employee personality definitions through root `Personalities.tyd`.

Official documentation describes a `PersonalityGraph` containing personalities and incompatibilities.

Key semantics:

- employees have two personality traits;
- personality construction uses either one neutral trait or a good + bad pairing;
- relationship values express affinity on a -1..1 scale;
- incompatibilities prevent specific personality combinations;
- replacement behavior can replace base personality data.

Current ModForge status: knowledge-ready, writer/validator deferred. ChatGPT may explain or draft research examples, but must not claim they are validated by the app until a dedicated schema/writer exists.

Source: `official-data-modding`.
