# Vanilla data version gap

The official Data Modding page currently exposes downloadable in-game data archives up to **Beta 1.7.15**.

The latest public patch observed during the 2026-08-25 research pass is **Beta 1.8.42**. ModForge's latest direct in-game semantic evidence is from **Beta 1.8.41**.

The 1.8.42 patch notes do not list a mod-format change, but that does not upgrade 1.8.41 evidence into a 1.8.42 game test.

Therefore:

- the 1.7.15 archive is valuable historical/structural vanilla evidence;
- it must not be labeled as exact 1.8.41 vanilla truth;
- rules that differ in 1.8.x need current in-game evidence, current official text, or a fresh user-supplied 1.8.41 vanilla data snapshot;
- future ModForge should support importing a user's local vanilla data as a versioned evidence layer.

This gap is explicitly tracked so ChatGPT and the app do not hallucinate current vanilla fields from an older archive.

Sources: `official-data-modding`, `official-patch-1.8.41`.
