# Game-version and knowledge update policy

Software Inc is actively updated. ModForge must version its knowledge separately from the game.

## Current state

- Latest public patch observed during this research pass: **1.8.42** (2026-08-20).
- Last ModForge in-game semantic validation: **1.8.41**.
- Latest official downloadable vanilla data archive linked by the Data Modding wiki: **Beta 1.7.15**.

These are intentionally three distinct facts.

## On every game patch

1. Record the new game version and official patch-note source.
2. Search patch notes for `mod`, `code mod`, `data mod`, `SIPL`, `TyD`, `furniture`, `hardware`, `localization`, security, compiler, serialization and Workshop changes.
3. Run static ModForge contract tests.
4. Run at least one known-valid data mod.
5. Run known-invalid in-game regression cases where practical.
6. Re-run code-mod compatibility tests when code-mod knowledge is active.
7. Promote version-specific observations only after reproducing them.
8. Never delete old evidence; mark rules with version applicability/deprecation.

## Local vanilla snapshot

Because the official downloadable data archive lags the latest public game patch, a future ModForge feature should import the user's installed vanilla data.

The importer should record:

- game version;
- source installation path;
- file list;
- SHA-256 per file;
- snapshot timestamp;
- normalized parsed entities;
- parser errors/warnings.

It should never modify the vanilla installation.

## Compatibility labels

Use:

- `LATEST_PUBLIC_PATCH`: latest observed public patch.
- `TESTED`: passed ModForge in-game regression suite on that version.
- `STRUCTURALLY_COMPATIBLE`: static rules appear compatible but no game run exists.
- `UNKNOWN`: no evidence.
- `BROKEN`: reproduced failure.

Do not collapse `STRUCTURALLY_COMPATIBLE` into `TESTED`.

Sources: `official-patch-1.8.42`, `official-data-modding`.
