# Code-mod operational constraints for the Beta 1.8 era

This is knowledge-only in the current ModForge product; executable code-mod generation remains frozen.

## Workshop source

- Development target: .NET Framework 4.
- Game-compiled source must stay within C# 3.
- Workshop code distribution uses source compiled by the game.
- Direct source mods should avoid enums because the official compiler issue can crash the game.
- Prefer public game APIs/events over runtime patching when an API hook exists.

## Full-access DLLs

Compiled DLL mods have a different security/distribution model.

`GiveMeFreedom` is a privileged/full-access mechanism for DLL-based mods. It must be treated as security-sensitive and must never be added automatically.

Full-access/unrestricted DLL distribution is not the normal Steam Workshop source path.

## UI

UI modifications remain Code mods, not a separate loader family.

When XML-like UI descriptions are used, attribute/key casing must be treated as significant.

## Networking

Network-enabled code mods must register a network id in the documented range `1..255`. Future conflict scanning should detect duplicate ids across installed code mods.

## Settings / save data

For Beta 1.8.34+:

- reject `UnityEngine.PlayerPrefs`;
- use `SaveSetting` / `LoadSetting` for global simple settings;
- use documented Serialize/Deserialize flows for per-save data.

## Version-aware source

The official API exposes Software Inc compile-time symbols for version families. Future code-mod linting should encourage version-gating of API differences instead of runtime string guesses.

Sources: `official-code-modding`, `official-patch-1.8.34-code-modding`.
