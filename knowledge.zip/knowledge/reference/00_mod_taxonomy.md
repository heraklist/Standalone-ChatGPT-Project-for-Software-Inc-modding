# Mod taxonomy and install roots

Software Inc has several mod families. ModForge must keep separate schemas because the formats, runtime risks and validation methods differ.

| Family | Local root | Main formats | Current ModForge status |
|---|---|---|---|
| Data mods | `Mods/<mod>/` | TyD, txt, optional SIPL | ACTIVE |
| Code mods | `DLLMods/<mod>/` | C# source or DLL | KNOWLEDGE READY / generation frozen |
| Furniture | `Furniture/<mod>/` | TyD + OBJ/textures | RESEARCHED / deferred |
| Materials | `Materials/<mod>/` | TyD + 256x256 PNG | RESEARCHED / deferred |
| Localization | `Localization/<language>/` or mod-local assets | TyD + text name lists | RESEARCHED / deferred |

Data mods can add/change/remove software types, AI company types, random name generators and employee personalities. Software features may attach SIPL scripts.

`meta.tyd` can provide display `Name`, `Description` and `Author`.

Sources: `official-modding`, `official-data-modding`.
