# Validation protocol

Static validation cannot prove complete Software Inc compatibility.

## Data-mod commands

- `RELOAD_MOD X`: reload a named data mod for testing.
- `CHECK_SPEC_REP X`: inspect specialization representation.
- `TEST_DEV_MOD X Y Z`: inspect SoftwareType/category balance and achievable submarket interest.
- `CHECK_ADDON_MARKET X Y Z`: inspect add-on market coverage.
- `GENERATE_LOCALIZATION X`: produce localization material.
- `LIST_SCOPE_MEMBERS X`: inspect available SIPL scope members.
- `INSTA_DEVELOP_DESIGN`: accelerate modded software testing.

## Code-mod commands

- `RECOMPILE_DLL_MOD`
- `RELOAD_DLL_MOD`
- `UNLOAD_DLL_MOD`

## ModForge gate model

A release report should label each check:

- `STATIC_PASS`
- `STATIC_FAIL`
- `GAME_REQUIRED`
- `GAME_PASS`
- `GAME_FAIL`
- `NOT_AVAILABLE`

Never translate `STATIC_PASS` into `GAME_PASS`.

Sources: `official-console`, `official-data-modding`, `official-code-modding`.


## Broader official development command surface

The machine-readable command catalog is `knowledge/rules/console_command_catalog.json`.

It records current official tooling across:

- general diagnostics: `SHOW_ON_ERROR`, `TOGGLE_VERBOSE`;
- Data: `RELOAD_MOD`, `CHECK_SPEC_REP`, `TEST_DEV_MOD`, `CHECK_ADDON_MARKET`;
- SIPL: `LIST_SCOPE_MEMBERS`;
- Furniture: `RELOAD_FURNITURE`, `FURNITURE_DEBUG`, `EXPORT_FURNITURE_BOUNDS`, `EXPORT_FURNITURE_POINTS`;
- Materials: `RELOAD_MATERIALS`;
- Code: `RECOMPILE_DLL_MOD`, `RELOAD_DLL_MOD`, `UNLOAD_DLL_MOD`, `EXECUTE`, `SHOW_INSPECTOR`;
- Localization: `COMPARE_LOCALIZATION`, `RELOAD_LOCALIZATION`, `GENERATE_LOCALIZATION`, `CONVERT_LOCALIZATION_TYD`;
- UI inspection: `UI_UNDER_MOUSE`, `UI_CHILDREN`, `UI_COMPONENTS`.

These commands are runtime evidence tools. Their presence in documentation is not equivalent to a PASS result.
