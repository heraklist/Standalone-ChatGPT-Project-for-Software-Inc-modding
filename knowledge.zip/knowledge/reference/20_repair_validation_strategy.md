# Repair and suggestion strategy

The validator answers: **what is wrong?**

The repair planner answers: **what can be changed safely, and who must decide?**

## SAFE_AUTO

Requirements:

- deterministic;
- reversible;
- does not reinterpret author gameplay intent;
- has a canonical rule + repair id;
- repaired ModSpec is revalidated before export.

Examples:

- quote/escape generated TyD strings;
- generate a local NameGenerator fallback when none is supplied;
- normalize an output extension/path;
- remove stale derived preview state.

## REVIEW_REQUIRED

Use when a change alters gameplay meaning.

Examples:

- choosing which root feature becomes the forced baseline;
- changing unlock years;
- changing submarket ratios;
- adding CompanyTypes for AI participation;
- moving category restrictions;
- changing dependencies.

The UI should show:

```text
Rule
Evidence/provenance
Confidence
Current value
Proposed operations
Gameplay-impact explanation
Approve / Reject
```

No repair is applied until approval.

## NEVER_AUTO

Examples:

- Override/Delete of vanilla or foreign content;
- editing another installed mod;
- SIPL/code generation or semantic rewrite;
- GiveMeFreedom / privileged file/network access;
- Harmony patch insertion;
- manufacturing-graph invention;
- compatibility changes whose merged result is ambiguous.

## Repair transaction

```text
original ModSpec
  ↓
diagnostics
  ↓
repair proposal
  ↓
user approval when required
  ↓
apply to an in-memory copy
  ↓
JSON Schema validation
  ↓
semantic validation
  ↓
knowledge rule validation
  ↓
diff preview
  ↓
commit to editor
```

Never mutate exported/installed files directly as the repair mechanism.

## Suggestions

Suggestions are allowed to be heuristic, but must be labeled with confidence and never block export solely because of taste/balance.

Examples:

- total DevTime seems unusually high;
- one submarket has very little feature coverage;
- category pricing differs strongly from nearby examples;
- AI participation is missing;
- recent installed mods touch the same SoftwareType.

The author remains the decision-maker.
