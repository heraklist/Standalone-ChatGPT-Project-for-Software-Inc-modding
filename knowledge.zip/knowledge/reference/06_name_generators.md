# NameGenerators

Random product names are generated from text files under `NameGenerators/`.

The generator id is the filename without `.txt`.

## Tree model

A generator file defines nodes. A node line begins with `-`, contains one or more next-node targets in parentheses, then one or more candidate text lines. Generation begins at `start`, appends a random candidate, moves to another referenced node, and continues until `stop`.

A first-line `[REPLACE]` directive replaces a built-in generator of the same id; otherwise same-name generators can merge according to the game behavior described by the official docs.

## Validation targets

A future NameGenerator validator should prove:

- a `start` node exists;
- referenced node ids exist;
- reachable branches can terminate at `stop`;
- a node has at least one candidate string;
- dangerous/ambiguous `[REPLACE]` use is explicit and review-required;
- a SoftwareType/category reference resolves to either generated/local content or a declared external reference.

## Current ModForge fallback

For the first-Beta SoftwareType profile, absence of a root generator causes ModForge to generate a deterministic local fallback:

```text
NameGenerators/<software-id>_names.txt
```

and emit root:

```text
NameGenerator <software-id>_names
```

That makes the current SoftwareType export self-contained.

Sources: `official-data-modding`, `observed-1.8.41-name-generator`.
