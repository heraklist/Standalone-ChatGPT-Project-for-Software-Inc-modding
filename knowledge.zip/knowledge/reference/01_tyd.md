# TyD reference

TyD is the text data language used broadly by Software Inc.

## Core model

A document is a sequence of records. A record has a name and a value. Values can be:

- simple/naked values;
- quoted strings;
- numbers;
- lists `[...]`;
- tables `{...}`;
- `null`.

Comments begin with `#` outside quoted strings. Lists contain anonymous values, so nested structured values inside lists are tables without record names.

## ModForge writer policy

- User-facing text is quoted.
- Identifier-like values are emitted naked only after strict validation.
- Backslashes, quotes, comment markers and newlines are escaped deterministically.
- Numeric output is stable and locale-independent.
- List ordering is preserved.
- Generated output must be byte-deterministic for the same validated ModSpec.

Source: `official-tyd`.
