# C# / DLL code mods

Code mods are executable and need a stronger safety model than data mods.

## Official setup

The official guide describes a .NET Framework 4 Class Library and references game/Unity assemblies from the Software Inc installation. The entry structure is:

- one `ModMeta` implementation as manager/metadata;
- one or more `ModBehaviour` implementations with Unity-style lifecycle.

Local mods live under `DLLMods/<mod>/`.

## Source versus DLL

Software Inc can compile `.cs` files itself. This source path:

- is limited to C# 3;
- is required for Steam Workshop source-mod publishing;
- receives game-injected error handling;
- has a documented enum compiler/crash issue, so straight source mods should avoid enums.

Compiled DLL mods allow more control but are a higher-trust distribution format.

## Compatibility

Beta 1.7+ game-compiled source mods can use Software Inc preprocessor symbols, including the Beta 1.8 symbol family, to isolate API/version differences.

## Threading

The official guide advises using ModBehaviour `Update`/Unity timing rather than custom worker loops for game/Unity interactions. Unity state from arbitrary threads risks races or invalid access.

## Settings and save data

Global simple settings can use `SaveSetting` / `LoadSetting`.

Per-save data uses Serialize/Deserialize with `WriteDictionary`. Custom serialized classes create removal compatibility risk. The `ModMeta.Name` is part of the save-data identity; changing it can make old data unreachable and name collisions can lose data.

## Files and privileged access

`ParentMod` provides relative-path loaders for supported asset types and blocks `../` traversal.

File-system/network access outside the normal sandbox needs the documented `GiveMeFreedom` mechanism, which applies to DLL-based mods and causes a user warning. ModForge should classify it as high-risk.

## Multiplayer/networking

Code mods can register network ids and send messages. Network-id collisions, missing peers, payload size and version compatibility all need runtime testing.

## Current ModForge policy

- code-mod knowledge/lint rules are included;
- automatic code generation is frozen in the current product scope;
- any future code-mod builder must have a separate security scanner and explicit executable-code approval.

Sources: `official-code-modding`, `official-modding`.


## Beta 1.8.34 security change

Official Beta 1.8.34 patch notes changed code-mod security behavior:

- code mods using `UnityEngine.PlayerPrefs` no longer load;
- migrate global settings to `ModBehaviour.SaveSetting` / `LoadSetting`;
- ModBehaviour Serialize/Deserialize support was expanded for save data;
- `EXECUTE` and `SHOW_INSPECTOR` were added/improved as mod-development tools.

For Beta 1.8+ linting, direct `UnityEngine.PlayerPrefs` usage should be a hard compatibility error, not merely a style warning.

Source: `official-patch-1.8.34-code-modding`.
